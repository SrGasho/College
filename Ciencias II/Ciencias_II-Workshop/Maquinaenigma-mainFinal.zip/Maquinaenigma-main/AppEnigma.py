from Rotor import Rotor
from Reflector import Reflector
from Main import Enigma
from CryptoParams import calcular_K, descifrar_parametro, validar_config

def crear_maquina_desde_config(config):
    validar_config(config)

    r0, r1, r2 = config["rotors"]
    rotor_izq = Rotor(r0["cableado"], r0["muesca"], r0["posicion"])
    rotor_med = Rotor(r1["cableado"], r1["muesca"], r1["posicion"])
    rotor_der = Rotor(r2["cableado"], r2["muesca"], r2["posicion"])
    reflector = Reflector(config["reflector"])

    return Enigma(rotor_izq, rotor_med, rotor_der, reflector)

if __name__ == "__main__":
    print("=== ENIGMA (3 rotores + reflector como parámetro CIFRADO) ===")
    print("K = (m*31 + d)*97 + (m + d)\n")

    m_txt = input("m (dato público): ").strip()
    d_txt = input("d (dato público): ").strip()
    if not m_txt.isdigit() or not d_txt.isdigit():
        raise ValueError("m y d deben ser números. Ejemplo: m=6, d=18")

    m = int(m_txt); d = int(d_txt)
    K = calcular_K(m, d)
    print("K calculada:", K)

    parametro = input("\nParámetro CIFRADO (string): ").strip()
    config = descifrar_parametro(parametro, K)

    maquina = crear_maquina_desde_config(config)

    texto = input("\nTexto (A-Z): ")
    print("Resultado:", maquina.cifrar_texto(texto))