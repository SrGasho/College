class Reflector:
    ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def __init__(self, cableado: str):
        cableado = cableado.strip().upper()
        if len(cableado) != 26 or sorted(cableado) != list(self.ABC):
            raise ValueError("Reflector inválido: debe ser una permutación de A-Z (26 letras).")
        self.cableado = cableado

    def reflejar(self, letra: str) -> str:
        return self.cableado[self.ABC.index(letra)]