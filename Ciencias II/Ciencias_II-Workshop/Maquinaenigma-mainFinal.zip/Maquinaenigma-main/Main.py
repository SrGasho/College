class Enigma:
    ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def __init__(self, rotor_izquierdo, rotor_medio, rotor_derecho, reflector):
        self.rotor_izquierdo = rotor_izquierdo
        self.rotor_medio = rotor_medio
        self.rotor_derecho = rotor_derecho
        self.reflector = reflector

    def _rotar_rotores(self):
        # Paso simple (suficiente para tu enunciado)
        self.rotor_derecho.avanzar()
        if self.rotor_derecho.en_muesca():
            self.rotor_medio.avanzar()
            if self.rotor_medio.en_muesca():
                self.rotor_izquierdo.avanzar()

    def cifrar_letra(self, letra: str) -> str:
        if letra not in self.ABC:
            return letra

        self._rotar_rotores()

        # Ida
        letra = self.rotor_derecho.adelante(letra)
        letra = self.rotor_medio.adelante(letra)
        letra = self.rotor_izquierdo.adelante(letra)

        # Reflector
        letra = self.reflector.reflejar(letra)

        # Regreso
        letra = self.rotor_izquierdo.atras(letra)
        letra = self.rotor_medio.atras(letra)
        letra = self.rotor_derecho.atras(letra)

        return letra

    def cifrar_texto(self, texto: str) -> str:
        # Importante: solo A-Z para evitar errores
        limpio = "".join(c for c in texto.upper() if "A" <= c <= "Z")
        return "".join(self.cifrar_letra(c) for c in limpio)