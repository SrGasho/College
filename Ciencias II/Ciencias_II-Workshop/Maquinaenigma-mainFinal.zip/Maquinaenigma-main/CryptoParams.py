import json
import base64
import hashlib
from typing import Dict, Any

def calcular_K(m: int, d: int) -> int:
    return (m * 31 + d) * 97 + (m + d)

def _keystream(k_int: int, n: int) -> bytes:
    seed = str(k_int).encode("utf-8")
    out = b""
    counter = 0
    while len(out) < n:
        out += hashlib.sha256(seed + counter.to_bytes(4, "big")).digest()
        counter += 1
    return out[:n]

def _xor_bytes(data: bytes, ks: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(data, ks))

def cifrar_parametro(config: Dict[str, Any], k_int: int) -> str:
    payload = json.dumps(config, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ks = _keystream(k_int, len(payload))
    ct = _xor_bytes(payload, ks)
    return base64.urlsafe_b64encode(ct).decode("ascii")

def descifrar_parametro(parametro_cifrado: str, k_int: int) -> Dict[str, Any]:
    try:
        ct = base64.urlsafe_b64decode(parametro_cifrado.encode("ascii"))
    except Exception as e:
        raise ValueError("Parámetro cifrado inválido: no es Base64 urlsafe válido.") from e

    ks = _keystream(k_int, len(ct))
    pt = _xor_bytes(ct, ks)

    try:
        return json.loads(pt.decode("utf-8"))
    except Exception as e:
        raise ValueError("Parámetro cifrado inválido: al descifrar no se obtiene JSON válido (K incorrecta o string incorrecto).") from e

def validar_config(config: Dict[str, Any]) -> None:
    if not isinstance(config, dict):
        raise ValueError("Config inválida: debe ser un diccionario.")

    if "rotors" not in config or "reflector" not in config:
        raise ValueError("Config inválida: debe tener 'rotors' y 'reflector'.")

    rotors = config["rotors"]
    if not isinstance(rotors, list) or len(rotors) != 3:
        raise ValueError("Config inválida: 'rotors' debe ser una lista de 3 rotores.")

    for i, r in enumerate(rotors):
        if not isinstance(r, dict):
            raise ValueError(f"Rotor {i} inválido: debe ser dict.")
        for key in ("cableado", "muesca", "posicion"):
            if key not in r:
                raise ValueError(f"Rotor {i} inválido: falta '{key}'.")

        cableado = str(r["cableado"]).upper()
        if len(cableado) != 26 or sorted(cableado) != list("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
            raise ValueError(f"Rotor {i} inválido: cableado debe ser permutación A-Z.")

        muesca = str(r["muesca"]).upper()
        if len(muesca) != 1 or muesca not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            raise ValueError(f"Rotor {i} inválido: muesca debe ser una letra A-Z.")

        pos = r["posicion"]
        if not isinstance(pos, int) or not (0 <= pos <= 25):
            raise ValueError(f"Rotor {i} inválido: posicion debe estar entre 0 y 25.")

    ref = str(config["reflector"]).upper()
    if len(ref) != 26 or sorted(ref) != list("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        raise ValueError("Reflector inválido: debe ser una permutación A-Z.")