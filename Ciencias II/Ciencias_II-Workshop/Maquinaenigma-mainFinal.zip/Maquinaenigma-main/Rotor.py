class Rotor:
    ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def __init__(self, cableado: str, muesca: str, posicion: int = 0):
        cableado = cableado.strip().upper()
        muesca = muesca.strip().upper()

        # Validar cableado
        if len(cableado) != 26 or sorted(cableado) != list(self.ABC):
            raise ValueError("Cableado inválido: debe ser una permutación de A-Z (26 letras).")

        # Validar muesca
        if len(muesca) != 1 or muesca not in self.ABC:
            raise ValueError("Muesca inválida: debe ser una letra A-Z.")

        # Validar posición
        if not isinstance(posicion, int) or not (0 <= posicion <= 25):
            raise ValueError("Posición inválida: debe ser un entero entre 0 y 25.")

        self.cableado = cableado
        self.muesca = muesca
        self.posicion = posicion % 26

        # Construir cableado inverso correctamente
        inverso = [""] * 26
        for i, letra_salida in enumerate(self.cableado):
            indice = self.ABC.index(letra_salida)
            inverso[indice] = self.ABC[i]

        self.cableado_inverso = "".join(inverso)

    def avanzar(self):
        self.posicion = (self.posicion + 1) % 26

    def en_muesca(self) -> bool:
        return self.ABC[self.posicion] == self.muesca

    def adelante(self, letra: str) -> str:
        # Shift por posición
        i = (self.ABC.index(letra) + self.posicion) % 26
        letra_cableada = self.cableado[i]

        # Unshift
        o = (self.ABC.index(letra_cableada) - self.posicion) % 26
        return self.ABC[o]

    def atras(self, letra: str) -> str:
        i = (self.ABC.index(letra) + self.posicion) % 26
        letra_cableada = self.cableado_inverso[i]

        o = (self.ABC.index(letra_cableada) - self.posicion) % 26
        return self.ABC[o]
