from CryptoParams import calcular_K, cifrar_parametro

config = {
    "rotors": [
        {"cableado": "EKMFLGDQVZNTOWYHXUSPAIBRCJ", "muesca": "Q", "posicion": 0},
        {"cableado": "AJDKSIRUXBLHWTMCQGZNPYFVOE", "muesca": "E", "posicion": 0},
        {"cableado": "BDFHJLCPRTXVZNYEIWGAKMUSQO", "muesca": "V", "posicion": 0},
    ],
    "reflector": "YRUHQSLDPXNGOKMIEBFZCWVJAT"
}

m = int(input("Ingrese m: ").strip())
d = int(input("Ingrese d: ").strip())

K = calcular_K(m, d)
print("K:", K)

parametro = cifrar_parametro(config, K)
print("\nParámetro CIFRADO generado:")
print(parametro)